package com.cart3r.cleaner

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.Capsule
import com.kyant.shapes.RoundedRectangle

private val Red = Color(0xFFFF2D4B)
private val Orange = Color(0xFFFF9F0A)
private val Yellow = Color(0xFFFFD60A)
private val Dim = Color.White.copy(0.6f)

@Composable
private fun T(s: String, size: Int = 14, color: Color = Color.White, w: FontWeight = FontWeight.Normal, mod: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) =
    BasicText(s, mod, style = TextStyle(color, size.sp, w), maxLines = maxLines)

private fun Modifier.tap(onClick: () -> Unit) = clickable(interactionSource = null, indication = null, onClick = onClick)

@Composable
private fun AnimBg(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Canvas(modifier) {
        drawRect(Color(0xFF050507))
        val r = size.width * 0.85f
        val c1 = Offset(size.width * (0.1f + 0.7f * a), size.height * (0.15f + 0.1f * a))
        val c2 = Offset(size.width * (0.9f - 0.7f * a), size.height * (0.75f - 0.1f * a))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE5173F).copy(0.8f), Color.Transparent), c1, r), r, c1)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF7A0A1A).copy(0.9f), Color.Transparent), c2, r), r, c2)
    }
}

@Composable
private fun Glass(b: Backdrop, modifier: Modifier = Modifier, r: Dp = 26.dp, tint: Color = Color.Unspecified, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.drawBackdrop(
            backdrop = b,
            shape = { RoundedRectangle(r) },
            effects = {
                vibrancy()
                blur(10f.dp.toPx())
                lens(12f.dp.toPx(), 22f.dp.toPx())
            },
            onDrawSurface = {
                drawRect(Color.White.copy(0.07f))
                if (tint != Color.Unspecified) drawRect(tint)
            }
        ),
        content = content
    )
}

@Composable
private fun GBtn(b: Backdrop, text: String, modifier: Modifier = Modifier, tint: Color = Red.copy(0.55f), onClick: () -> Unit) {
    Row(
        modifier
            .drawBackdrop(
                backdrop = b,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(10f.dp.toPx(), 20f.dp.toPx())
                },
                onDrawSurface = { drawRect(tint) }
            )
            .tap(onClick)
            .height(52.dp)
            .padding(horizontal = 22.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) { T(text, 16, w = FontWeight.SemiBold) }
}

@Composable
private fun Pill(text: String, bg: Color, onClick: () -> Unit) {
    Box(Modifier.clip(Capsule()).background(bg).tap(onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        T(text, 13, w = FontWeight.SemiBold)
    }
}

@Composable
private fun Ring(score: Int?) {
    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 14.dp.toPx()
            val s = Size(size.width - w, size.height - w)
            val tl = Offset(w / 2, w / 2)
            drawArc(Color.White.copy(0.1f), 135f, 270f, false, topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
            if (score != null) drawArc(Red, 135f, 270f * score / 100f, false, topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T(score?.toString() ?: "–", 44, w = FontWeight.Bold)
            T("stan telefonu", 12, Dim)
        }
    }
}

@Composable
fun Root() {
    val screen by Store.screen.collectAsState()
    val backdrop = rememberLayerBackdrop()
    BackHandler(screen != Screen.HOME) { if (screen == Screen.SCAN) Store.cancel() else Store.screen.value = Screen.HOME }
    Box(Modifier.fillMaxSize()) {
        AnimBg(Modifier.fillMaxSize().layerBackdrop(backdrop))
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            when (screen) {
                Screen.HOME -> Home(backdrop)
                Screen.SCAN -> ScanUi(backdrop)
                Screen.RESULTS -> Results(backdrop)
                Screen.OPT -> OptUi(backdrop)
            }
        }
    }
}

@Composable
private fun Home(b: Backdrop) {
    val ctx = LocalContext.current
    val perm by Store.perm.collectAsState()
    val scanned by Store.scanned.collectAsState()
    val list by Store.findings.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            T("CART3R", 13, Red, FontWeight.Bold)
            T("Cleaner", 36, w = FontWeight.Bold)
        }
        Glass(b, Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Ring(if (scanned) Store.score(list) else null)
                T(if (scanned) "Ostatni skan: ${list.size} elementów do przejrzenia" else "Uruchom skan, aby ocenić telefon", 13, Dim)
            }
        }
        if (!perm.files || !perm.usage) {
            Glass(b, Modifier.fillMaxWidth(), tint = Red.copy(0.12f)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Aby skan był pełny, przyznaj dostęp:", 14, w = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!perm.files) Pill("Wszystkie pliki", Red) { openFiles(ctx) }
                        if (!perm.usage) Pill("Dane o użyciu", Red) { openUsage(ctx) }
                    }
                }
            }
        }
        Mode.entries.forEach { m ->
            Glass(b, Modifier.fillMaxWidth().tap { Store.scan(ctx, m) }) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    T(m.icon, 28)
                    Column(Modifier.weight(1f)) {
                        T(m.label, 17, w = FontWeight.SemiBold)
                        T(m.desc, 12, Dim)
                    }
                    T("›", 24, Red)
                }
            }
        }
        GBtn(b, "⚙️  Optymalizuj telefon", Modifier.fillMaxWidth()) { Store.analyze(ctx) }
    }
}

@Composable
private fun ScanUi(b: Backdrop) {
    val p by Store.progress.collectAsState()
    val s by Store.stage.collectAsState()
    val n by Store.found.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Glass(b, Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(26.dp), Arrangement.spacedBy(14.dp), Alignment.CenterHorizontally) {
                T("${(p * 100).toInt()}%", 56, w = FontWeight.Bold)
                Box(Modifier.fillMaxWidth().height(8.dp).clip(Capsule()).background(Color.White.copy(0.1f))) {
                    Box(Modifier.fillMaxWidth(p.coerceIn(0.02f, 1f)).fillMaxHeight().background(Red))
                }
                T(s, 13, Dim, maxLines = 2)
                T("Znaleziono: $n", 15, Red, FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(20.dp))
        GBtn(b, "Anuluj", tint = Color.White.copy(0.1f)) { Store.cancel() }
    }
}

@Composable
private fun Chip(text: String, on: Boolean, click: () -> Unit) {
    Box(Modifier.clip(Capsule()).background(if (on) Red else Color.White.copy(0.1f)).tap(click).padding(horizontal = 14.dp, vertical = 8.dp)) {
        T(text, 13, w = FontWeight.SemiBold)
    }
}

@Composable
private fun Results(b: Backdrop) {
    val ctx = LocalContext.current
    val all by Store.findings.collectAsState()
    val sel by Store.selected.collectAsState()
    var cat by remember { mutableStateOf<Cat?>(null) }
    val list = remember(all, cat) {
        all.filter { cat == null || it.cat == cat }.sortedWith(compareByDescending<Finding> { it.risk }.thenByDescending { it.size })
    }
    val selSize = all.filter { it.id in sel }.sumOf { it.size }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Glass(b, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Wyniki skanu", 22, w = FontWeight.Bold)
                    T("${all.size} elementów • do zwolnienia ${fmt(all.filter { it.file }.sumOf { it.size })}", 13, Dim)
                }
                Pill("Wróć", Color.White.copy(0.12f)) { Store.screen.value = Screen.HOME }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Wszystko (${all.size})", cat == null) { cat = null }
            Cat.entries.forEach { c ->
                val n = all.count { it.cat == c }
                if (n > 0) Chip("${c.label} ($n)", cat == c) { cat = c }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("Nic tu nie ma 🎉", 16, Dim) }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { f -> FindingRow(f, f.id in sel) }
            }
        }
        if (sel.isNotEmpty()) GBtn(b, "🗑  Usuń zaznaczone (${sel.size} • ${fmt(selSize)})", Modifier.fillMaxWidth()) { Store.deleteSelected(ctx) }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun FindingRow(f: Finding, checked: Boolean) {
    val ctx = LocalContext.current
    val shape = RoundedRectangle(20.dp)
    val dot = if (f.cat != Cat.THREAT) Color.Transparent else if (f.risk >= 4) Red else if (f.risk >= 2) Orange else Yellow
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White.copy(0.06f)).border(1.dp, Color.White.copy(0.08f), shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (f.file) {
                Box(
                    Modifier.size(24.dp).clip(RoundedRectangle(8.dp)).background(if (checked) Red else Color.White.copy(0.12f)).tap { Store.toggle(f.id) },
                    contentAlignment = Alignment.Center
                ) { if (checked) T("✓", 14, w = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (dot != Color.Transparent) Box(Modifier.size(8.dp).clip(Capsule()).background(dot))
                    T(f.title, 15, w = FontWeight.SemiBold, maxLines = 1, mod = Modifier.weight(1f, fill = false))
                }
                T(f.detail, 12, Dim, maxLines = 3)
            }
            if (f.size > 0) T(fmt(f.size), 13, Red, FontWeight.SemiBold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val p = f.pkg
            val label = if (p == null) "Usuń" else if (f.cat == Cat.BG) "Ogranicz" else "Odinstaluj"
            Pill(label, Red) {
                if (p == null) Store.deleteOne(ctx, f)
                else if (f.cat == Cat.BG) start(ctx, details(p))
                else Store.uninstall(ctx, p)
            }
            Pill("Zostaw", Color.White.copy(0.12f)) { Store.keep(f) }
        }
    }
}

@Composable
private fun OptUi(b: Backdrop) {
    val ctx = LocalContext.current
    val list by Store.opts.collectAsState()
    val busy by Store.optBusy.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Glass(b, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Optymalizacja", 22, w = FontWeight.Bold)
                    T(if (busy) "Analizuję telefon…" else "${list.size} możliwości, aby było płynniej", 13, Dim)
                }
                Pill("Wróć", Color.White.copy(0.12f)) { Store.screen.value = Screen.HOME }
            }
        }
        if (!busy && list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("Wszystko wygląda dobrze 🎉", 16, Dim) }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { o ->
                    val shape = RoundedRectangle(20.dp)
                    val dot = when (o.sev) { 3 -> Red; 2 -> Orange; 1 -> Yellow; else -> Color.White.copy(0.4f) }
                    Column(
                        Modifier.fillMaxWidth().clip(shape).background(Color.White.copy(0.06f)).border(1.dp, Color.White.copy(0.08f), shape).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(Capsule()).background(dot))
                            T(o.title, 15, w = FontWeight.SemiBold)
                        }
                        T(o.detail, 12, Dim)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (o.run != null) Pill(o.btn, Red) { o.run.invoke(ctx) }
                            Pill(if (o.run != null) "Zostaw" else "OK", Color.White.copy(0.12f)) { Store.dropOpt(o) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
