package com.cart3r.cleaner

import android.net.Uri
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.viewinterop.AndroidView
import com.cart3r.cleaner.glass.LiquidToggle
import com.kyant.backdrop.Backdrop
import com.kyant.shapes.Capsule
import com.kyant.shapes.RoundedRectangle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
internal fun StorageBar(b: Backdrop) {
    val (used, total) = Store.storage.collectAsState().value
    val f by animateFloatAsState((used.toFloat() / total).coerceIn(0f, 1f), tween(1000), label = "st")
    Glass(b, Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                T("Pamięć", 15, w = FontWeight.SemiBold, mod = Modifier.weight(1f))
                T("${fmt(used)} / ${fmt(total)}", 13, Dim)
            }
            Box(Modifier.fillMaxWidth().height(10.dp).clip(Capsule()).background(Color.White.copy(0.1f))) {
                Box(Modifier.fillMaxWidth(f.coerceAtLeast(0.02f)).fillMaxHeight().background(if (f > 0.9f) Red else Orange))
            }
        }
    }
}

@Composable
private fun Head(b: Backdrop, title: String, sub: String, back: String? = null, onBack: () -> Unit = {}, action: (@Composable () -> Unit)? = null) {
    Glass(b, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                T(title, 22, w = FontWeight.Bold)
                T(sub, 13, Dim)
            }
            action?.invoke()
            if (back != null) Pill(back, Color.White.copy(0.12f), onBack)
        }
    }
}

@Composable
internal fun MediaUi(b: Backdrop) {
    val ctx = LocalContext.current
    val list by Store.videos.collectAsState()
    val busy by Store.mediaBusy.collectAsState()
    val perm by Store.perm.collectAsState()
    LaunchedEffect(perm.files) { if (perm.files && !Store.mediaLoaded) Store.loadMedia(ctx) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Head(b, "Wideo", if (busy) "Szukam wideo…" else "${list.size} plików • ${fmt(list.sumOf { it.size })}", action = {
            Pill("Odśwież", Color.White.copy(0.12f)) { Store.loadMedia(ctx) }
        })
        if (!perm.files) {
            Glass(b, Modifier.fillMaxWidth(), tint = Red.copy(0.12f)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Aby znaleźć wideo, przyznaj dostęp do wszystkich plików.", 14)
                    Pill("Wszystkie pliki", Red) { openFiles(ctx) }
                }
            }
        } else if (!busy && list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("Nie znaleziono wideo", 16, Dim) }
        } else {
            LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.path }) { v -> VideoCard(v) }
            }
        }
    }
}

@Composable
private fun VideoCard(v: Vid) {
    val meta by produceState<Meta?>(null, v.path) { value = withContext(Dispatchers.IO) { Media.meta(v) } }
    val shape = RoundedRectangle(20.dp)
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).clip(shape).background(Color.White.copy(0.08f))
            .tap { Store.playing.value = v; Store.screen.value = Screen.PLAYER }
    ) {
        meta?.thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Box(Modifier.align(Alignment.Center).size(44.dp).clip(Capsule()).background(Color.Black.copy(0.4f)), contentAlignment = Alignment.Center) { T("▶", 18) }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(0.45f)).padding(horizontal = 10.dp, vertical = 6.dp)) {
            T(meta?.let { if (it.dur > 0) Media.dur(it.dur) else "" } ?: "", 12, mod = Modifier.weight(1f))
            T(fmt(v.size), 12, Red, FontWeight.SemiBold)
        }
    }
}

@Composable
internal fun PlayerUi(b: Backdrop) {
    val ctx = LocalContext.current
    val v = Store.playing.collectAsState().value
    var confirm by remember { mutableStateOf(false) }
    if (v == null) { Store.screen.value = Screen.MEDIA; return }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Head(b, "Podgląd", "${v.name} • ${fmt(v.size)}", "Wróć", { Store.screen.value = Screen.MEDIA })
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedRectangle(24.dp)).background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val vv = VideoView(c)
                    vv.setVideoURI(Uri.fromFile(File(v.path)))
                    vv.setMediaController(MediaController(c).also { it.setAnchorView(vv) })
                    vv.setOnPreparedListener { vv.start() }
                    FrameLayout(c).apply { addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER)) }
                },
                onRelease = { (it.getChildAt(0) as? VideoView)?.stopPlayback() }
            )
        }
        GBtn(b, if (confirm) "Na pewno? Dotknij, aby usunąć" else "🗑  Usuń wideo", Modifier.fillMaxWidth()) {
            if (confirm) Store.deleteVideo(ctx, v) else confirm = true
        }
        Box(Modifier.height(4.dp))
    }
}

@Composable
internal fun AppsUi(b: Backdrop) {
    val ctx = LocalContext.current
    val list by Store.apps.collectAsState()
    val busy by Store.appsBusy.collectAsState()
    val perm by Store.perm.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Head(b, "Ranking aplikacji", if (busy) "Analizuję…" else "Największe zainstalowane aplikacje", "Wróć", { Store.screen.value = Screen.TOOLS })
        if (!perm.usage) {
            Glass(b, Modifier.fillMaxWidth(), tint = Red.copy(0.12f)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Rozmiary aplikacji wymagają dostępu do danych o użyciu.", 14)
                    Pill("Dane o użyciu", Red) { openUsage(ctx) }
                }
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.pkg }) { a ->
                val shape = RoundedRectangle(20.dp)
                Row(
                    Modifier.animateItem().fillMaxWidth().clip(shape).background(Color.White.copy(0.06f)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        T(a.label, 15, w = FontWeight.SemiBold, maxLines = 1)
                        val last = if (a.lastUsed > 0) "ostatnio ${(System.currentTimeMillis() - a.lastUsed) / Apps.DAY} dni temu" else "brak danych o użyciu"
                        T("${fmt(a.size)} • $last", 12, Dim, maxLines = 1)
                    }
                    Pill("Odinstaluj", Red) { Store.uninstall(ctx, a.pkg) }
                }
            }
        }
    }
}

@Composable
private fun Tool(b: Backdrop, icon: String, title: String, desc: String, onClick: () -> Unit) {
    Glass(b, Modifier.fillMaxWidth().tap(onClick)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            T(icon, 26)
            Column(Modifier.weight(1f)) {
                T(title, 16, w = FontWeight.SemiBold)
                T(desc, 12, Dim)
            }
            T("›", 24, Red)
        }
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(Capsule()).background(if (ok) Color(0xFF30D158) else Red))
        T(label, 14, mod = Modifier.weight(1f).padding(start = 8.dp))
        if (ok) T("Przyznano", 12, Dim) else Pill("Przyznaj", Red, onGrant)
    }
}

@Composable
internal fun ToolsUi(b: Backdrop) {
    val ctx = LocalContext.current
    val perm by Store.perm.collectAsState()
    val live by Store.liveBg.collectAsState()
    val anims by Store.anims.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            T("CART3R", 13, Red, FontWeight.Bold)
            T("Narzędzia", 36, w = FontWeight.Bold)
        }
        Appear(0) { Tool(b, "⚙️", "Optymalizacja", "Tło, animacje, bateria, oszczędzanie") { Store.analyze(ctx) } }
        Appear(1) { Tool(b, "📊", "Ranking aplikacji", "Największe aplikacje i nieużywane") { Store.loadApps(ctx) } }
        Appear(2) { Tool(b, "🎬", "Wideo", "Przeglądaj i usuwaj największe filmy") { Store.screen.value = Screen.MEDIA } }
        Appear(3) {
            Glass(b, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    T("Uprawnienia", 16, w = FontWeight.SemiBold)
                    PermRow("Wszystkie pliki", perm.files) { openFiles(ctx) }
                    PermRow("Dane o użyciu", perm.usage) { openUsage(ctx) }
                }
            }
        }
        Appear(4) {
            Glass(b, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    T("Wygląd", 16, w = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("Animowane tło", 14, mod = Modifier.weight(1f))
                        LiquidToggle({ live }, { Store.setCfg(ctx, "bg", it) }, b)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("Animacje przejść", 14, mod = Modifier.weight(1f))
                        LiquidToggle({ anims }, { Store.setCfg(ctx, "anim", it) }, b)
                    }
                }
            }
        }
    }
}
