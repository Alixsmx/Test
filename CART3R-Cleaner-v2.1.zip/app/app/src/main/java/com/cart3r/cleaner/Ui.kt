package com.cart3r.cleaner

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import com.cart3r.cleaner.glass.LiquidBottomTab
import com.cart3r.cleaner.glass.LiquidBottomTabs
import com.cart3r.cleaner.glass.LiquidButton
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.shapes.Capsule
import com.kyant.shapes.RoundedRectangle

internal val Red = Color(0xFFFF2D4B)
internal val Orange = Color(0xFFFF9F0A)
internal val Yellow = Color(0xFFFFD60A)
internal val Dim = Color.White.copy(0.6f)

@Composable
internal fun T(s: String, size: Int = 14, color: Color = Color.White, w: FontWeight = FontWeight.Normal, mod: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) =
    BasicText(s, mod, style = TextStyle(color, size.sp, w), maxLines = maxLines)

internal fun Modifier.tap(onClick: () -> Unit) = clickable(interactionSource = null, indication = null, onClick = onClick)

@Composable
internal fun AnimBg(modifier: Modifier, live: Boolean = true) {
    val t = rememberInfiniteTransition(label = "bg")
    val anim by t.animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val a = if (live) anim else 0.5f
    Canvas(modifier) {
        drawRect(Color(0xFF050507))
        val r = size.width * 0.85f
        val c1 = Offset(size.width * (0.1f + 0.7f * a), size.height * (0.15f + 0.1f * a))
        val c2 = Offset(size.width * (0.9f - 0.7f * a), size.height * (0.75f - 0.1f * a))
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE5173F).copy(0.8f), Color.Transparent), c1, r), r, c1)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF7A0A1A).copy(0.9f), Color.Transparent), c2, r), r, c2)
    }
}

@Composable
internal fun Glass(b: Backdrop, modifier: Modifier = Modifier, r: Dp = 26.dp, tint: Color = Color.Unspecified, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.drawBackdrop(
            backdrop = b,
            shape = { RoundedRectangle(r) },
            effects = {
                vibrancy()
                blur(10f.dp.toPx())
                lens(12f.dp.toPx(), 22f.dp.toPx())
            },
            onDrawSurface = {
                drawRect(Color.White.copy(0.07f))
                if (tint != Color.Unspecified) drawRect(tint)
            }
        ),
        content = content
    )
}

@Composable
internal fun GBtn(b: Backdrop, text: String, modifier: Modifier = Modifier, tint: Color = Red.copy(0.55f), onClick: () -> Unit) {
    LiquidButton(onClick, b, modifier, tint = tint) { T(text, 16, w = FontWeight.SemiBold) }
}

@Composable
internal fun Appear(i: Int, content: @Composable () -> Unit) {
    val on = Store.anims.value
    var show by remember { mutableStateOf(!on) }
    LaunchedEffect(Unit) { if (on) { delay(i * 70L); show = true } }
    val p by animateFloatAsState(if (show) 1f else 0f, tween(450), label = "ap")
    Box(Modifier.fillMaxWidth().graphicsLayer { alpha = p; translationY = (1f - p) * 36.dp.toPx() }) { content() }
}

@Composable
internal fun Pill(text: String, bg: Color, onClick: () -> Unit) {
    Box(Modifier.clip(Capsule()).background(bg).tap(onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        T(text, 13, w = FontWeight.SemiBold)
    }
}

@Composable
private fun Ring(score: Int?) {
    val sc by animateFloatAsState(score?.toFloat() ?: 0f, tween(1100), label = "ring")
    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 14.dp.toPx()
            val s = Size(size.width - w, size.height - w)
            val tl = Offset(w / 2, w / 2)
            drawArc(Color.White.copy(0.1f), 135f, 270f, false, topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
            if (score != null) drawArc(Red, 135f, 270f * sc / 100f, false, topLeft = tl, size = s, style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T(if (score != null) sc.toInt().toString() else "–", 44, w = FontWeight.Bold)
            T("stan telefonu", 12, Dim)
        }
    }
}

private val TABS = setOf(Screen.HOME, Screen.MEDIA, Screen.TOOLS)

@Composable
fun Root() {
    val screen by Store.screen.collectAsState()
    val anims by Store.anims.collectAsState()
    val live by Store.liveBg.collectAsState()
    val bg = rememberLayerBackdrop()
    val top = rememberLayerBackdrop()
    BackHandler(screen != Screen.HOME) {
        Store.screen.value = when (screen) {
            Screen.SCAN -> { Store.cancel(); Screen.HOME }
            Screen.PLAYER -> Screen.MEDIA
            Screen.APPS -> Screen.TOOLS
            else -> Screen.HOME
        }
    }
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(top)) {
            AnimBg(Modifier.fillMaxSize().layerBackdrop(bg), live)
            AnimatedContent(
                targetState = screen,
                modifier = Modifier.fillMaxSize().systemBarsPadding(),
                transitionSpec = {
                    if (anims) (fadeIn(tween(320)) + scaleIn(tween(320), 0.94f)) togetherWith (fadeOut(tween(180)) + scaleOut(tween(180), 1.04f))
                    else EnterTransition.None togetherWith ExitTransition.None
                },
                label = "screen"
            ) { s ->
                Box(Modifier.fillMaxSize().padding(bottom = if (s in TABS) 92.dp else 0.dp)) {
                    when (s) {
                        Screen.HOME -> Home(bg)
                        Screen.SCAN -> ScanUi(bg)
                        Screen.RESULTS -> Results(bg)
                        Screen.OPT -> OptUi(bg)
                        Screen.MEDIA -> MediaUi(bg)
                        Screen.PLAYER -> PlayerUi(bg)
                        Screen.TOOLS -> ToolsUi(bg)
                        Screen.APPS -> AppsUi(bg)
                    }
                }
            }
        }
        Box(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp), contentAlignment = Alignment.BottomCenter) {
            AnimatedVisibility(screen in TABS, enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it }, exit = fadeOut(tween(200)) + slideOutVertically(tween(200)) { it }) {
                val idx = when (screen) { Screen.MEDIA -> 1; Screen.TOOLS -> 2; else -> 0 }
                LiquidBottomTabs(
                    selectedTabIndex = { idx },
                    onTabSelected = { Store.screen.value = when (it) { 1 -> Screen.MEDIA; 2 -> Screen.TOOLS; else -> Screen.HOME } },
                    backdrop = top,
                    tabsCount = 3,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LiquidBottomTab({ Store.screen.value = Screen.HOME }) { T("⌂", 20); T("Start", 11) }
                    LiquidBottomTab({ Store.screen.value = Screen.MEDIA }) { T("▶", 18); T("Wideo", 11) }
                    LiquidBottomTab({ Store.screen.value = Screen.TOOLS }) { T("✦", 20); T("Narzędzia", 11) }
                }
            }
        }
    }
}

@Composable
private fun Home(b: Backdrop) {
    val ctx = LocalContext.current
    val perm by Store.perm.collectAsState()
    val scanned by Store.scanned.collectAsState()
    val list by Store.findings.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            T("CART3R", 13, Red, FontWeight.Bold)
            T("Cleaner", 36, w = FontWeight.Bold)
        }
        Appear(0) {
            Glass(b, Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Ring(if (scanned) Store.score(list) else null)
                    T(if (scanned) "Ostatni skan: ${list.size} elementów do przejrzenia" else "Uruchom skan, aby ocenić telefon", 13, Dim)
                }
            }
        }
        Appear(1) { StorageBar(b) }
        if (!perm.files || !perm.usage) {
            Glass(b, Modifier.fillMaxWidth(), tint = Red.copy(0.12f)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Aby skan był pełny, przyznaj dostęp:", 14, w = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!perm.files) Pill("Wszystkie pliki", Red) { openFiles(ctx) }
                        if (!perm.usage) Pill("Dane o użyciu", Red) { openUsage(ctx) }
                    }
                }
            }
        }
        Mode.entries.forEachIndexed { i, m ->
            Appear(i + 2) {
                Glass(b, Modifier.fillMaxWidth().tap { Store.scan(ctx, m) }) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        T(m.icon, 28)
                        Column(Modifier.weight(1f)) {
                            T(m.label, 17, w = FontWeight.SemiBold)
                            T(m.desc, 12, Dim)
                        }
                        T("›", 24, Red)
                    }
                }
            }
        }
        Appear(5) { GBtn(b, "⚙️  Optymalizuj telefon", Modifier.fillMaxWidth()) { Store.analyze(ctx) } }
    }
}

@Composable
private fun ScanUi(b: Backdrop) {
    val p by Store.progress.collectAsState()
    val s by Store.stage.collectAsState()
    val n by Store.found.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Glass(b, Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(26.dp), Arrangement.spacedBy(14.dp), Alignment.CenterHorizontally) {
                val ap by animateFloatAsState(p, tween(300), label = "p")
                val pulse = rememberInfiniteTransition(label = "pulse")
                val k by pulse.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "k")
                Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (o in floatArrayOf(0f, 0.5f)) {
                            val q = (k + o) % 1f
                            drawCircle(Red.copy(0.5f * (1f - q)), size.minDimension * (0.3f + 0.2f * q), style = Stroke(3.dp.toPx()))
                        }
                    }
                    T("${(ap * 100).toInt()}%", 40, w = FontWeight.Bold)
                }
                Box(Modifier.fillMaxWidth().height(8.dp).clip(Capsule()).background(Color.White.copy(0.1f))) {
                    Box(Modifier.fillMaxWidth(ap.coerceIn(0.02f, 1f)).fillMaxHeight().background(Red))
                }
                T(s, 13, Dim, maxLines = 2)
                T("Znaleziono: $n", 15, Red, FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(20.dp))
        GBtn(b, "Anuluj", tint = Color.White.copy(0.1f)) { Store.cancel() }
    }
}

@Composable
internal fun Chip(text: String, on: Boolean, click: () -> Unit) {
    Box(Modifier.clip(Capsule()).background(if (on) Red else Color.White.copy(0.1f)).tap(click).padding(horizontal = 14.dp, vertical = 8.dp)) {
        T(text, 13, w = FontWeight.SemiBold)
    }
}

@Composable
private fun Results(b: Backdrop) {
    val ctx = LocalContext.current
    val all by Store.findings.collectAsState()
    val sel by Store.selected.collectAsState()
    var cat by remember { mutableStateOf<Cat?>(null) }
    val list = remember(all, cat) {
        all.filter { cat == null || it.cat == cat }.sortedWith(compareByDescending<Finding> { it.risk }.thenByDescending { it.size })
    }
    val selSize = all.filter { it.id in sel }.sumOf { it.size }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Glass(b, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Wyniki skanu", 22, w = FontWeight.Bold)
                    T("${all.size} elementów • do zwolnienia ${fmt(all.filter { it.file }.sumOf { it.size })}", 13, Dim)
                }
                Pill("Wróć", Color.White.copy(0.12f)) { Store.screen.value = Screen.HOME }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Wszystko (${all.size})", cat == null) { cat = null }
            Cat.entries.forEach { c ->
                val n = all.count { it.cat == c }
                if (n > 0) Chip("${c.label} ($n)", cat == c) { cat = c }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("Nic tu nie ma 🎉", 16, Dim) }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { f -> FindingRow(f, f.id in sel, Modifier.animateItem()) }
            }
        }
        if (sel.isNotEmpty()) GBtn(b, "🗑  Usuń zaznaczone (${sel.size} • ${fmt(selSize)})", Modifier.fillMaxWidth()) { Store.deleteSelected(ctx) }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun FindingRow(f: Finding, checked: Boolean, mod: Modifier = Modifier) {
    val ctx = LocalContext.current
    val shape = RoundedRectangle(20.dp)
    val dot = if (f.cat != Cat.THREAT) Color.Transparent else if (f.risk >= 4) Red else if (f.risk >= 2) Orange else Yellow
    Column(
        mod.fillMaxWidth().clip(shape).background(Color.White.copy(0.06f)).border(1.dp, Color.White.copy(0.08f), shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (f.file) {
                Box(
                    Modifier.size(24.dp).clip(RoundedRectangle(8.dp)).background(if (checked) Red else Color.White.copy(0.12f)).tap { Store.toggle(f.id) },
                    contentAlignment = Alignment.Center
                ) { if (checked) T("✓", 14, w = FontWeight.Bold) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (dot != Color.Transparent) Box(Modifier.size(8.dp).clip(Capsule()).background(dot))
                    T(f.title, 15, w = FontWeight.SemiBold, maxLines = 1, mod = Modifier.weight(1f, fill = false))
                }
                T(f.detail, 12, Dim, maxLines = 3)
            }
            if (f.size > 0) T(fmt(f.size), 13, Red, FontWeight.SemiBold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val p = f.pkg
            val label = if (p == null) "Usuń" else if (f.cat == Cat.BG) "Ogranicz" else "Odinstaluj"
            Pill(label, Red) {
                if (p == null) Store.deleteOne(ctx, f)
                else if (f.cat == Cat.BG) start(ctx, details(p))
                else Store.uninstall(ctx, p)
            }
            Pill("Zostaw", Color.White.copy(0.12f)) { Store.keep(f) }
        }
    }
}

@Composable
private fun OptUi(b: Backdrop) {
    val ctx = LocalContext.current
    val list by Store.opts.collectAsState()
    val busy by Store.optBusy.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Glass(b, Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Optymalizacja", 22, w = FontWeight.Bold)
                    T(if (busy) "Analizuję telefon…" else "${list.size} możliwości, aby było płynniej", 13, Dim)
                }
                Pill("Wróć", Color.White.copy(0.12f)) { Store.screen.value = Screen.HOME }
            }
        }
        if (!busy && list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { T("Wszystko wygląda dobrze 🎉", 16, Dim) }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { o ->
                    val shape = RoundedRectangle(20.dp)
                    val dot = when (o.sev) { 3 -> Red; 2 -> Orange; 1 -> Yellow; else -> Color.White.copy(0.4f) }
                    Column(
                        Modifier.animateItem().fillMaxWidth().clip(shape).background(Color.White.copy(0.06f)).border(1.dp, Color.White.copy(0.08f), shape).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(Capsule()).background(dot))
                            T(o.title, 15, w = FontWeight.SemiBold)
                        }
                        T(o.detail, 12, Dim)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (o.run != null) Pill(o.btn, Red) { o.run.invoke(ctx) }
                            Pill(if (o.run != null) "Zostaw" else "OK", Color.White.copy(0.12f)) { Store.dropOpt(o) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
