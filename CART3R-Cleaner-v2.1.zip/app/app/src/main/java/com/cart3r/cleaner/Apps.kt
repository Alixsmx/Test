package com.cart3r.cleaner

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process

class App(
    val pkg: String, val label: String, val perms: Set<String>, val installer: String?,
    val installed: Long, val lastUsed: Long, val size: Long, val cache: Long,
    val statsKnown: Boolean, val launchable: Boolean
)

object Apps {
    const val DAY = 86_400_000L

    fun hasUsage(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun usageMap(ctx: Context): Map<String, Long> {
        val usm = ctx.getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val m = HashMap<String, Long>()
        for (iv in intArrayOf(UsageStatsManager.INTERVAL_WEEKLY, UsageStatsManager.INTERVAL_MONTHLY, UsageStatsManager.INTERVAL_YEARLY)) {
            usm.queryUsageStats(iv, now - 120 * DAY, now)?.forEach { s ->
                val t = maxOf(s.lastTimeUsed, s.lastTimeVisible)
                if (t > (m[s.packageName] ?: 0L)) m[s.packageName] = t
            }
        }
        return m
    }

    @Suppress("DEPRECATION")
    fun list(ctx: Context, withStats: Boolean): List<App> {
        val pm = ctx.packageManager
        val usage = if (withStats && hasUsage(ctx)) usageMap(ctx) else null
        val ssm = if (usage != null) ctx.getSystemService(StorageStatsManager::class.java) else null
        val out = ArrayList<App>()
        for (pi in pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            val ai = pi.applicationInfo ?: continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 || pi.packageName == ctx.packageName) continue
            val installer = try { pm.getInstallSourceInfo(pi.packageName).installingPackageName } catch (_: Exception) { null }
            var size = 0L
            var cache = 0L
            if (ssm != null) {
                try {
                    val st = ssm.queryStatsForPackage(ai.storageUuid, pi.packageName, Process.myUserHandle())
                    size = st.appBytes + st.dataBytes
                    cache = st.cacheBytes
                } catch (_: Exception) {}
            }
            out.add(
                App(
                    pi.packageName, pm.getApplicationLabel(ai).toString(), pi.requestedPermissions?.toSet() ?: emptySet(),
                    installer, pi.firstInstallTime, usage?.get(pi.packageName) ?: 0L, size, cache,
                    usage != null, pm.getLaunchIntentForPackage(pi.packageName) != null
                )
            )
        }
        return out
    }
}
