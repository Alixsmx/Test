package com.cart3r.cleaner

enum class Mode(val icon: String, val label: String, val desc: String) {
    QUICK("⚡", "Szybkie skanowanie", "Pobrane, tymczasowe, kosz, APK, podejrzane aplikacje"),
    DEEP("🔍", "Dokładne skanowanie", "Cała pamięć, duże pliki, nieużywane aplikacje, zagrożenia"),
    FULL("🛡️", "Pełne skanowanie", "Wszystko: duplikaty, tło, dostępność, administratorzy, APK")
}

enum class Cat(val label: String) {
    THREAT("Zagrożenia"), JUNK("Śmieci"), TRASH("Usunięte"), APK("Pliki APK"), LARGE("Duże pliki"),
    DUP("Duplikaty"), EMPTY("Puste foldery"), UNUSED("Nieużywane"), BG("W tle")
}

enum class Screen { HOME, SCAN, RESULTS, OPT, MEDIA, PLAYER, TOOLS, APPS }

class Finding(
    val id: Int, val cat: Cat, val title: String, val detail: String,
    val size: Long, val path: String? = null, val pkg: String? = null, val risk: Int = 0
) {
    val file: Boolean get() = path != null
}

class Opt(val id: Int, val title: String, val detail: String, val btn: String, val sev: Int, val run: ((android.content.Context) -> Unit)?)

class Perm(val files: Boolean, val usage: Boolean)

fun fmt(b: Long): String = when {
    b >= 1L shl 30 -> "%.1f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.0f MB".format(b / 1048576.0)
    b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}
