package com.cart3r.cleaner

import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.os.Environment
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File

class Vid(val path: String, val name: String, val size: Long, val mod: Long)

class Meta(val thumb: ImageBitmap?, val dur: Long)

object Media {
    private val EXT = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi", "m4v")
    private val cache = LruCache<String, Meta>(80)

    fun scan(): List<Vid> {
        val out = ArrayList<Vid>()
        val st = ArrayDeque<Pair<File, Int>>()
        st.addLast(Environment.getExternalStorageDirectory() to 0)
        while (st.isNotEmpty() && out.size < 800) {
            val (dir, d) = st.removeLast()
            val kids = dir.listFiles() ?: continue
            for (f in kids) {
                if (f.isDirectory) {
                    if (d == 0 && f.name.equals("Android", true)) continue
                    if (d < 8 && !f.name.startsWith(".")) st.addLast(f to d + 1)
                } else if (f.extension.lowercase() in EXT && f.length() > 100_000) {
                    out.add(Vid(f.path, f.name, f.length(), f.lastModified()))
                }
            }
        }
        return out.sortedByDescending { it.size }
    }

    fun meta(v: Vid): Meta {
        cache.get(v.path)?.let { return it }
        var th: ImageBitmap? = null
        var d = 0L
        try { th = ThumbnailUtils.createVideoThumbnail(File(v.path), Size(360, 360), null).asImageBitmap() } catch (_: Exception) {}
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(v.path)
            d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
        } catch (_: Exception) {}
        return Meta(th, d).also { cache.put(v.path, it) }
    }

    fun dur(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }
}
