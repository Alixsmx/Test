package com.cart3r.cleaner

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

fun toast(c: Context, m: String) {
    val app = c.applicationContext
    Handler(Looper.getMainLooper()).post { Toast.makeText(app, m, Toast.LENGTH_LONG).show() }
}

@Suppress("DEPRECATION")
object Store {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val AUTO = setOf(Cat.JUNK, Cat.TRASH, Cat.EMPTY, Cat.APK)
    private var job: Job? = null

    val screen = MutableStateFlow(Screen.HOME)
    val progress = MutableStateFlow(0f)
    val stage = MutableStateFlow("")
    val found = MutableStateFlow(0)
    val findings = MutableStateFlow<List<Finding>>(emptyList())
    val selected = MutableStateFlow<Set<Int>>(emptySet())
    val scanned = MutableStateFlow(false)
    val opts = MutableStateFlow<List<Opt>>(emptyList())
    val optBusy = MutableStateFlow(false)
    val perm = MutableStateFlow(Perm(false, false))
    val videos = MutableStateFlow<List<Vid>>(emptyList())
    val mediaBusy = MutableStateFlow(false)
    val playing = MutableStateFlow<Vid?>(null)
    val apps = MutableStateFlow<List<App>>(emptyList())
    val appsBusy = MutableStateFlow(false)
    val storage = MutableStateFlow(0L to 1L)
    val liveBg = MutableStateFlow(true)
    val anims = MutableStateFlow(true)
    var mediaLoaded = false

    fun loadCfg(ctx: Context) {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        liveBg.value = p.getBoolean("bg", true)
        anims.value = p.getBoolean("anim", true)
    }

    fun setCfg(ctx: Context, key: String, v: Boolean) {
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putBoolean(key, v).apply()
        if (key == "bg") liveBg.value = v else anims.value = v
    }

    fun loadMedia(ctx: Context) {
        val c = ctx.applicationContext
        if (!Environment.isExternalStorageManager()) { toast(c, "Przyznaj dostęp do wszystkich plików"); return }
        if (mediaBusy.value) return
        mediaBusy.value = true
        scope.launch(Dispatchers.IO) {
            try { videos.value = Media.scan(); mediaLoaded = true }
            catch (e: Exception) { toast(c, "Błąd skanu wideo: ${e.message}") }
            finally { mediaBusy.value = false }
        }
    }

    fun deleteVideo(ctx: Context, v: Vid) {
        val c = ctx.applicationContext
        scope.launch(Dispatchers.IO) {
            val f = File(v.path)
            val ok = f.absolutePath.startsWith(Environment.getExternalStorageDirectory().absolutePath) && (f.delete() || !f.exists())
            if (ok) {
                videos.update { l -> l.filter { it.path != v.path } }
                playing.value = null
                screen.value = Screen.MEDIA
                toast(c, "Usunięto: ${fmt(v.size)}")
            } else toast(c, "Nie udało się usunąć")
        }
    }

    fun loadApps(ctx: Context) {
        val c = ctx.applicationContext
        screen.value = Screen.APPS
        appsBusy.value = true
        scope.launch(Dispatchers.IO) {
            try { apps.value = Apps.list(c, true).sortedByDescending { it.size }.take(30) }
            catch (e: Exception) { toast(c, "Błąd: ${e.message}") }
            finally { appsBusy.value = false }
        }
    }

    fun refresh(ctx: Context) {
        perm.value = Perm(Environment.isExternalStorageManager(), Apps.hasUsage(ctx))
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            storage.value = (st.totalBytes - st.availableBytes) to st.totalBytes.coerceAtLeast(1L)
        } catch (_: Exception) {}
        val l = findings.value
        if (l.none { it.pkg != null }) return
        val pm = ctx.packageManager
        val gone = l.filter { f ->
            val p = f.pkg
            p != null && try { pm.getPackageInfo(p, 0); false } catch (_: Exception) { true }
        }.map { it.id }.toSet()
        if (gone.isNotEmpty()) findings.update { it.filter { f -> f.id !in gone } }
    }

    fun scan(ctx: Context, mode: Mode) {
        val c = ctx.applicationContext
        job?.cancel()
        progress.value = 0f; stage.value = "Start…"; found.value = 0
        screen.value = Screen.SCAN
        job = scope.launch {
            try {
                val r = Scanner(c, mode) { p, s, n -> progress.value = p; stage.value = s; found.value = n }.run()
                findings.value = r
                selected.value = r.filter { it.file && it.cat in AUTO }.map { it.id }.toSet()
                scanned.value = true
                screen.value = Screen.RESULTS
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(c, "Błąd skanowania: ${e.message}")
                screen.value = Screen.HOME
            }
        }
    }

    fun cancel() { job?.cancel(); screen.value = Screen.HOME }

    fun toggle(id: Int) = selected.update { if (id in it) it - id else it + id }

    fun keep(f: Finding) {
        findings.update { l -> l.filter { it.id != f.id } }
        selected.update { it - f.id }
    }

    private fun rm(f: Finding): Boolean {
        val p = f.path ?: return false
        val file = File(p)
        if (!file.absolutePath.startsWith(Environment.getExternalStorageDirectory().absolutePath)) return false
        val ok = if (file.isDirectory) file.deleteRecursively() else file.delete()
        return ok || !file.exists()
    }

    fun deleteOne(ctx: Context, f: Finding) {
        val c = ctx.applicationContext
        scope.launch(Dispatchers.IO) {
            if (rm(f)) { keep(f); toast(c, "Usunięto: ${fmt(f.size)}") } else toast(c, "Nie udało się usunąć")
        }
    }

    fun deleteSelected(ctx: Context) {
        val c = ctx.applicationContext
        scope.launch(Dispatchers.IO) {
            val ids = selected.value
            val gone = HashSet<Int>()
            var freed = 0L
            for (f in findings.value) if (f.id in ids && f.file && rm(f)) { gone += f.id; freed += f.size }
            findings.update { l -> l.filter { it.id !in gone } }
            selected.update { it - gone }
            toast(c, "Usunięto ${gone.size} elementów (${fmt(freed)})")
        }
    }

    fun uninstall(ctx: Context, pkg: String) = start(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))

    fun analyze(ctx: Context) {
        val c = ctx.applicationContext
        screen.value = Screen.OPT
        optBusy.value = true
        scope.launch(Dispatchers.IO) {
            try { opts.value = Optimizer.analyze(c).sortedByDescending { it.sev } }
            catch (e: Exception) { toast(c, "Błąd analizy: ${e.message}") }
            finally { optBusy.value = false }
        }
    }

    fun dropOpt(o: Opt) = opts.update { l -> l.filter { it.id != o.id } }

    fun score(l: List<Finding>): Int {
        val th = l.filter { it.cat == Cat.THREAT }.sumOf { if (it.risk >= 4) 15 else 8 }
        val mb = l.filter { it.file && it.cat != Cat.THREAT && it.cat != Cat.LARGE }.sumOf { it.size } shr 20
        val apps = l.count { it.cat == Cat.UNUSED || it.cat == Cat.BG }
        return (100 - th - minOf(30L, mb / 200).toInt() - minOf(15, apps * 2)).coerceIn(5, 100)
    }
}
