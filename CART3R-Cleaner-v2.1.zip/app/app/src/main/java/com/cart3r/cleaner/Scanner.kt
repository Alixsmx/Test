package com.cart3r.cleaner

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.view.accessibility.AccessibilityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

class Scanner(private val ctx: Context, private val mode: Mode, private val report: (Float, String, Int) -> Unit) {
    private val out = ArrayList<Finding>()
    private val perCat = HashMap<Cat, Int>()
    private val paths = HashSet<String>()
    private val bySize = HashMap<Long, MutableList<File>>()
    private val root = Environment.getExternalStorageDirectory()
    private var id = 0
    private var seen = 0

    companion object {
        val JUNK_EXT = setOf("tmp", "temp", "log", "bak", "old", "cache", "thumb", "dmp", "crdownload", "part")
        val TRASH_DIRS = setOf(".trash", ".trashed", ".recycle", "recyclebin", "lost.dir")
        val JUNK_DIRS = setOf(".thumbnails", ".cache", "cache", "tmp", "temp", "logs") + TRASH_DIRS
        val TRUSTED = setOf(
            "com.android.vending", "com.heytap.market", "com.oppo.market", "com.sec.android.app.samsungapps",
            "com.amazon.venezia", "com.huawei.appmarket"
        )
        val BG_PERMS = setOf(
            "RECEIVE_BOOT_COMPLETED", "ACCESS_BACKGROUND_LOCATION", "FOREGROUND_SERVICE", "WAKE_LOCK",
            "SCHEDULE_EXACT_ALARM", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
        )
    }

    private fun add(cat: Cat, title: String, detail: String, size: Long, path: String? = null, pkg: String? = null, risk: Int = 0) {
        val n = perCat[cat] ?: 0
        if (n >= 400) return
        if (path != null && !paths.add(path)) return
        perCat[cat] = n + 1
        out.add(Finding(id++, cat, title, detail, size, path, pkg, risk))
    }

    suspend fun run(): List<Finding> = withContext(Dispatchers.IO) {
        if (Environment.isExternalStorageManager()) files() else report(0.05f, "Brak dostępu do plików – pomijam pamięć", 0)
        apps()
        if (mode == Mode.FULL) dups()
        report(1f, "Gotowe", out.size)
        out
    }

    private suspend fun files() {
        when (mode) {
            Mode.QUICK -> { walk(root, 1); walk(File(root, "Download"), 4) }
            Mode.DEEP -> walk(root, 8)
            Mode.FULL -> walk(root, 14)
        }
    }

    private suspend fun walk(start: File, maxDepth: Int) {
        val st = ArrayDeque<Pair<File, Int>>()
        st.addLast(start to 0)
        while (st.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val (dir, d) = st.removeLast()
            val kids = dir.listFiles() ?: continue
            if (kids.isEmpty() && d >= 2) add(Cat.EMPTY, dir.name, dir.parent ?: "", 0, dir.path)
            for (f in kids) {
                val n = f.name.lowercase()
                if (f.isDirectory) {
                    if (d == 0 && n == "android" && start == root) continue
                    if (n in JUNK_DIRS) { junkDir(f, n); continue }
                    if (d < maxDepth) st.addLast(f to d + 1)
                } else {
                    file(f, n)
                }
                if (++seen % 300 == 0) report(0.02f + 0.55f * seen / (seen + 20000f), "Skanuję pliki… $seen", out.size)
            }
        }
    }

    private fun size(f: File): Long = f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun junkDir(f: File, n: String) {
        val sz = size(f)
        if (sz <= 0) return
        add(if (n in TRASH_DIRS) Cat.TRASH else Cat.JUNK, f.name, f.parent ?: "", sz, f.path)
    }

    private fun file(f: File, n: String) {
        val len = f.length()
        val ext = n.substringAfterLast('.', "")
        if (mode == Mode.FULL && len >= 1L shl 20 && ext != "apk") bySize.getOrPut(len) { ArrayList() }.add(f)
        when {
            n.startsWith(".trashed-") -> add(Cat.TRASH, f.name.substringAfter('-').substringAfter('-'), "Kosz systemowy", len, f.path)
            ext == "apk" -> apk(f, len)
            ext in JUNK_EXT && len > 0 -> add(Cat.JUNK, f.name, "Plik tymczasowy / log", len, f.path)
            mode != Mode.QUICK && len >= 150L shl 20 -> add(Cat.LARGE, f.name, f.parent ?: "", len, f.path)
        }
    }

    @Suppress("DEPRECATION")
    private fun apk(f: File, len: Long) {
        val pi = try { ctx.packageManager.getPackageArchiveInfo(f.path, PackageManager.GET_PERMISSIONS) } catch (_: Exception) { null }
        val (risk, why) = riskOf(pi?.requestedPermissions?.toSet() ?: emptySet(), true)
        if (risk >= 3) add(Cat.THREAT, f.name, "APK w pamięci • $why", len, f.path, risk = risk)
        else add(Cat.APK, f.name, "Instalator APK" + (pi?.packageName?.let { " • $it" } ?: ""), len, f.path)
    }

    private fun riskOf(p: Set<String>, side: Boolean): Pair<Int, String> {
        var r = 0
        val w = ArrayList<String>()
        if (side) { r += 1; w += "spoza sklepu" }
        if (p.any { it.endsWith("SEND_SMS") || it.endsWith("READ_SMS") || it.endsWith("RECEIVE_SMS") }) { r += 2; w += "dostęp do SMS" }
        if ("android.permission.SYSTEM_ALERT_WINDOW" in p) { r += 1; w += "nakładki na ekran" }
        if ("android.permission.REQUEST_INSTALL_PACKAGES" in p) { r += 1; w += "instaluje inne aplikacje" }
        if ("android.permission.READ_CALL_LOG" in p) { r += 1; w += "rejestr połączeń" }
        if (side && "android.permission.RECORD_AUDIO" in p && "android.permission.READ_CONTACTS" in p) { r += 1; w += "mikrofon + kontakty" }
        return r to w.joinToString(" • ")
    }

    private fun accessibilityPkgs(): Set<String> = try {
        ctx.getSystemService(AccessibilityManager::class.java)
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .mapNotNull { it.resolveInfo?.serviceInfo?.packageName }.toSet()
    } catch (_: Exception) { emptySet() }

    private fun adminPkgs(): Set<String> = try {
        ctx.getSystemService(DevicePolicyManager::class.java).activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()
    } catch (_: Exception) { emptySet() }

    private suspend fun apps() {
        report(0.6f, "Analizuję aplikacje…", out.size)
        val list = Apps.list(ctx, mode != Mode.QUICK)
        val acc = if (mode == Mode.QUICK) emptySet() else accessibilityPkgs()
        val adm = if (mode == Mode.QUICK) emptySet() else adminPkgs()
        val now = System.currentTimeMillis()
        for ((i, a) in list.withIndex()) {
            currentCoroutineContext().ensureActive()
            if (i % 5 == 0) report(0.6f + 0.3f * i / list.size, "Analizuję: ${a.label}", out.size)
            val side = a.installer == null || a.installer !in TRUSTED
            var (r, why) = riskOf(a.perms, side)
            if (a.pkg in acc) { r += 2; why += (if (why.isEmpty()) "" else " • ") + "usługa dostępności (widzi ekran)" }
            if (a.pkg in adm) { r += 2; why += (if (why.isEmpty()) "" else " • ") + "administrator urządzenia" }
            val flag = if (mode == Mode.FULL) r >= 2 else r >= 3
            if (flag) add(Cat.THREAT, a.label, why, a.size, pkg = a.pkg, risk = r)
            if (mode == Mode.QUICK || !a.statsKnown || !a.launchable) continue
            val idle = if (a.lastUsed == 0L) 120 else ((now - a.lastUsed) / Apps.DAY).toInt()
            val idleTxt = if (idle >= 120) ">120" else "$idle"
            if (idle >= 45 && now - a.installed > 45 * Apps.DAY) {
                add(Cat.UNUSED, a.label, "Nieużywana od $idleTxt dni", a.size, pkg = a.pkg)
            } else if (mode == Mode.FULL && idle >= 7) {
                val bg = a.perms.count { it.substringAfterLast('.') in BG_PERMS }
                if (bg >= 3) add(Cat.BG, a.label, "Może działać w tle ($bg uprawnień) • nieużywana od $idleTxt dni", a.size, pkg = a.pkg)
            }
        }
    }

    private fun quickHash(f: File): String? = try {
        val md = MessageDigest.getInstance("MD5")
        val buf = ByteArray(65536)
        RandomAccessFile(f, "r").use { r ->
            val len = r.length()
            for (pos in longArrayOf(0, (len / 2 - 32768).coerceAtLeast(0), (len - 65536).coerceAtLeast(0))) {
                r.seek(pos)
                val n = r.read(buf)
                if (n > 0) md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { null }

    private suspend fun dups() {
        val groups = bySize.values.filter { it.size > 1 }
        for ((i, g) in groups.withIndex()) {
            currentCoroutineContext().ensureActive()
            if (i % 10 == 0) report(0.9f + 0.09f * i / groups.size, "Szukam duplikatów…", out.size)
            val byHash = HashMap<String, MutableList<File>>()
            for (f in g) { val h = quickHash(f) ?: continue; byHash.getOrPut(h) { ArrayList() }.add(f) }
            for (l in byHash.values) {
                if (l.size < 2) continue
                l.sortBy { it.lastModified() }
                for (c in l.drop(1)) add(Cat.DUP, c.name, "Prawdopodobna kopia: ${l[0].path.removePrefix(root.path)}", c.length(), c.path)
            }
        }
    }
}
