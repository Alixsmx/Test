package com.cart3r.cleaner

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Display

fun start(ctx: Context, vararg its: Intent) {
    for (i in its) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
    }
    toast(ctx, "Nie można otworzyć tego ustawienia na tym telefonie")
}

fun details(pkg: String) = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))

fun openFiles(ctx: Context) = start(
    ctx,
    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")),
    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
)

fun openUsage(ctx: Context) = start(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

object Optimizer {
    private const val BOOT = "android.permission.RECEIVE_BOOT_COMPLETED"
    private const val BGLOC = "android.permission.ACCESS_BACKGROUND_LOCATION"

    fun analyze(ctx: Context): List<Opt> {
        val o = ArrayList<Opt>()
        fun add(t: String, d: String, b: String, s: Int, run: ((Context) -> Unit)?) { o.add(Opt(o.size, t, d, b, s, run)) }

        val sf = StatFs(Environment.getDataDirectory().path)
        val free = sf.availableBytes * 100 / sf.totalBytes
        if (free < 20) add("Mało wolnej pamięci ($free%)", "Poniżej 20% telefon zwalnia i się zacina. Uruchom Dokładne skanowanie i usuń zbędne rzeczy.", "Skanuj", 3) { Store.scan(it, Mode.DEEP) }

        val mi = ActivityManager.MemoryInfo()
        ctx.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val ram = 100 - mi.availMem * 100 / mi.totalMem
        if (ram > 80) add("RAM zajęta w $ram%", "Zamknij niepotrzebne aplikacje w ostatnich. Aplikacje „czyszczące RAM” tylko spowalniają.", "Aplikacje", 2) { start(it, Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS)) }

        val cr = ctx.contentResolver
        fun g(k: String) = Settings.Global.getFloat(cr, k, 1f)
        val an = listOf(g(Settings.Global.WINDOW_ANIMATION_SCALE), g(Settings.Global.TRANSITION_ANIMATION_SCALE), g(Settings.Global.ANIMATOR_DURATION_SCALE))
        if (an.any { it > 0.6f }) add("Animacje systemu: ${an.max()}x", "Opcje programisty → ustaw skalę animacji okna, przejść i długości na 0,5x. System wyda się szybszy.", "Opcje programisty", 1) {
            start(it, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS), Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))
        }
        if (Settings.Global.getInt(cr, Settings.Global.ALWAYS_FINISH_ACTIVITIES, 0) == 1)
            add("„Nie zachowuj działań” jest włączone", "Opcja programisty, która zamyka aplikacje po wyjściu i mocno zwalnia telefon. Wyłącz.", "Opcje programisty", 3) { start(it, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }

        if (ctx.getSystemService(PowerManager::class.java).isPowerSaveMode)
            add("Oszczędzanie baterii jest włączone", "Ogranicza wydajność procesora i animacje, przez co telefon działa wolniej.", "Ustawienia", 2) { start(it, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }

        try {
            val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
            val cur = d.refreshRate
            val max = d.supportedModes.maxOf { it.refreshRate }
            if (max - cur > 20) add("Ekran: ${cur.toInt()} Hz (max ${max.toInt()} Hz)", "Wyższe odświeżanie daje płynniejszy ekran. Sprawdź, czy w ustawieniach wyświetlacza nie masz 60 Hz.", "Ekran", 0) { start(it, Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        } catch (_: Exception) {}

        val days = SystemClock.elapsedRealtime() / Apps.DAY
        if (days >= 5) add("Telefon działa już $days dni bez restartu", "Restart czyści pamięć i procesy w tle. Zrestartuj telefon dla większej płynności.", "OK", 1, null)

        val usageOk = Apps.hasUsage(ctx)
        if (!usageOk) add("Brak dostępu do danych o użyciu", "Bez tego nie wiem, których aplikacji nie używasz. Przyznaj dostęp, a analiza będzie dokładna.", "Przyznaj", 2) { openUsage(it) }

        val apps = Apps.list(ctx, true)
        val now = System.currentTimeMillis()
        fun idle(a: App) = if (a.lastUsed == 0L) 120 else ((now - a.lastUsed) / Apps.DAY).toInt()
        fun idleTxt(a: App) = if (idle(a) >= 120) ">120" else "${idle(a)}"

        if (usageOk) {
            apps.filter { BOOT in it.perms && it.launchable && idle(it) >= 14 }.sortedByDescending { idle(it) }.take(8).forEach { a ->
                add("${a.label} – autostart", "Nieużywana od ${idleTxt(a)} dni, a startuje z systemem i zjada RAM oraz baterię. Wyłącz autostart.", "Wyłącz autostart", 2) { c ->
                    start(c, Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")), details(a.pkg))
                }
            }
            apps.filter { it.cache > 200L shl 20 }.sortedByDescending { it.cache }.take(5).forEach { a ->
                add("${a.label} – cache ${fmt(a.cache)}", "Duży cache spowalnia i zajmuje miejsce. Wejdź w Pamięć i wyczyść cache.", "Otwórz", 1) { c -> start(c, details(a.pkg)) }
            }
        }
        val pw = ctx.getSystemService(PowerManager::class.java)
        apps.filter { pw.isIgnoringBatteryOptimizations(it.pkg) }.take(5).forEach { a ->
            add("${a.label} omija oszczędzanie baterii", "Aplikacja ma wyłączone ograniczenia i może działać w tle bez przerwy. Zostaw tylko jeśli jej potrzebujesz.", "Bateria", 1) { c -> start(c, details(a.pkg)) }
        }
        apps.filter { BGLOC in it.perms && ctx.packageManager.checkPermission(BGLOC, it.pkg) == PackageManager.PERMISSION_GRANTED }.take(5).forEach { a ->
            add("${a.label} śledzi lokalizację w tle", "Ciągłe GPS mocno zużywa baterię. Zmień na „tylko podczas używania”.", "Uprawnienia", 1) { c -> start(c, details(a.pkg)) }
        }
        return o
    }
}
